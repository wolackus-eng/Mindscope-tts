# MindScope TTS 1.0 – APK ohne Android Studio auf dem Smartphone bauen

## Voraussetzungen
Ein kostenloses GitHub-Konto und eine Internetverbindung für den einmaligen Cloud-Build. Die App selbst kann danach eine auf dem Smartphone installierte Offline-TTS-Engine verwenden.

## Vorgehen
1. Öffne https://github.com/new und erstelle ein **privates** Repository, z. B. `mindscope-tts`.
2. Entpacke `MindScope_TTS_1_0_Android_Projekt_mit_Build.zip`.
3. Lade **den Inhalt** des Ordners `MindScopeTTS_1_0` ins Repository hoch. Der versteckte Ordner `.github/workflows/` muss enthalten sein; wenn die Upload-Oberfläche versteckte Ordner nicht übernimmt, füge die Workflowdatei `.github/workflows/android-apk.yml` über „Add file > Create new file“ separat hinzu.
4. Öffne im Repository **Actions**, dann **Android APK erstellen**, dann **Run workflow**. Ein Push auf `main` oder `master` startet den Build ebenfalls.
5. Bei erfolgreichem Build: auf der Laufseite unter **Artifacts** `MindScope-TTS-1.0-Debug-APK` herunterladen und ZIP entpacken.
6. Öffne `app-debug.apk` auf deinem vivo X300. Erlaube auf Nachfrage die Installation aus dieser Quelle.
7. Installiere bei Bedarf eine geeignete deutsche **Offline-TTS-Engine** und wähle dort eine deutsche Stimme. Starte dann MindScope TTS und teste einen kurzen Text.

## Wichtige Einschränkungen
Dies ist eine Entwicklungs-/Test-App, kein fertig getestetes Produkt. Der APK-Build wurde in dieser Sitzung mangels Android SDK/Gradle und Netzwerk **nicht ausgeführt**. Die Version verwendet Android TextToSpeech mit extern installierter Engine. Sie bietet **WAV-Export**, **keinen MP3-Export** und **noch keine automatischen separaten Charakterstimmen**. Hörbuchqualität hängt sehr stark von der installierten Engine ab. Der Aufruf von `synthesizeToFile` wird nicht von allen TTS-Anbietern gleich gut unterstützt. Kleine WAVs testen, bevor lange Texte erzeugt werden.

Wenn GitHub Actions einen Fehler meldet, gib mir den Text des fehlerhaften Build-Schritts, damit ich das Projekt gezielt korrigiere.
