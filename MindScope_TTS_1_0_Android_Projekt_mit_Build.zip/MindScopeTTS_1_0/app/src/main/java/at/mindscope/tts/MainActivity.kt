package at.mindscope.tts

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.view.View
import android.widget.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale
import java.util.UUID
import kotlin.concurrent.thread

/** v1 test: Android TTS provider, offline voice only. Native voice model is supplied by a separate installed provider. */
class MainActivity : Activity(), TextToSpeech.OnInitListener {
 private lateinit var tts: TextToSpeech
 private lateinit var status: TextView
 private lateinit var input: EditText
 private lateinit var voiceChoice: Spinner
 private lateinit var roleChoice: Spinner
 private lateinit var rate: SeekBar
 private var voices: List<Voice> = emptyList()
 private var documentUri: Uri? = null
 private val chooseTxt = 100
 private var exportParts = mutableListOf<File>()
 private var exportChunks = listOf<String>()
 private var exportIndex = 0
 private var isExporting = false
 private var pendingWav: Uri? = null
 private var working = false

 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val outer = ScrollView(this); val layout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,24,28,24) }
  outer.addView(layout); setContentView(outer)
  fun title(t:String) = TextView(this).apply { text=t; textSize=18f; setPadding(0,14,0,9); layout.addView(this) }
  fun button(t:String, action:()->Unit) = Button(this).apply { text=t; layout.addView(this); setOnClickListener { action() } }
  title("MindScope TTS 1.0 · Offline-Hörbuch-Test")
  status = TextView(this).apply { text="Sprachengine wird initialisiert …"; layout.addView(this) }
  button("TXT-Datei laden") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="text/plain"; addCategory(Intent.CATEGORY_OPENABLE) }, chooseTxt) }
  title("Text (auch Rollen: ERZÄHLER:, THANE:, RHEX:, KORD:)")
  input = EditText(this).apply { minLines=8; setText("ERZÄHLER: Die Memoria Invicta glitt lautlos durch die Dunkelheit.\nTHANE: Bewahrt die Namen.\nKORD: Die Maschine erinnert sich."); layout.addView(this) }
  title("Stimme – nur lokal installierte deutsche Stimmen")
  voiceChoice = Spinner(this); layout.addView(voiceChoice)
  title("Sprecherrolle (für Vorschau)")
  roleChoice = Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item, listOf("ERZÄHLER","THANE","RHEX","VARRO","KORD")); layout.addView(this) }
  title("Sprechgeschwindigkeit")
  rate = SeekBar(this).apply { max=60; progress=25; layout.addView(this) }
  button("Vorlesen") { startSpeech() }
  button("Stopp") { if (::tts.isInitialized) tts.stop(); status.text="Gestoppt" }
  button("Kapitel als WAV exportieren") { if (!isExporting) { startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply { type="audio/wav"; putExtra(Intent.EXTRA_TITLE,"MindScope_Hoerbuch.wav") },101) } }
  title("Wichtig: Die App nutzt eine gesondert installierte Android-Offline-TTS-Engine. Wähle eine hochwertige deutsche Stimme in den Android-TTS-Einstellungen. MP3-Export folgt in der nächsten Version; WAV funktioniert mit kompatibler Engine.")
  tts=TextToSpeech(this,this)
 }
 override fun onInit(code:Int) {
  if(code!=TextToSpeech.SUCCESS){status.text="TTS-Engine nicht verfügbar";return}
  val all=tts.voices?.filter { it.locale.language=="de" && !it.isNetworkConnectionRequired }?.sortedBy { it.name } ?: emptyList()
  voices=all
  voiceChoice.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,all.map { "${it.name} (${it.locale})" })
  status.text=if(all.isEmpty())"Keine deutsche OFFLINE-Stimme installiert. Installiere eine geeignete Android-TTS-Engine und starte diese App neu." else "${all.size} lokale deutsche Stimme(n) verfügbar"
  tts.setOnUtteranceProgressListener(object:UtteranceProgressListener(){
   override fun onStart(utteranceId:String?) { runOnUiThread{status.text="Sprache wird erzeugt …"} }
   override fun onDone(utteranceId:String?) { if(isExporting) runOnUiThread { exportIndex++; exportNext() } else runOnUiThread{status.text="Wiedergabe abgeschlossen"} }
   override fun onError(utteranceId:String?) { runOnUiThread { isExporting=false;status.text="TTS-Ausgabe fehlgeschlagen (${utteranceId ?: "unbekannt"})" } }
  })
 }
 private fun segments(txt:String):List<String> {
  val text=txt.replace("\r\n","\n").trim()
  val groups=Regex("(?<=[.!?])\\s+|(?<=\\n)").split(text).filter{it.isNotBlank()}
  val out=mutableListOf<String>(); var buffer=""
  val maxChars=minOf(1700,TextToSpeech.getMaxSpeechInputLength()-40)
  for(part in groups) {
    for(piece in part.chunked(maxChars)) {
      if(buffer.length+piece.length+1>maxChars && buffer.isNotEmpty()) {out.add(buffer);buffer=""}
      buffer=if(buffer.isEmpty())piece else "$buffer $piece"
    }
  }
  if(buffer.isNotEmpty())out.add(buffer)
  return out
 }
 private fun cleanRoles(s:String)=s.replace(Regex("(?m)^\\s*(ERZÄHLER|THANE|RHEX|VARRO|KORD|SEVERIAN KORD)\\s*:\\s*", RegexOption.IGNORE_CASE), "")
 private fun voiceAndSpeed(){ voices.getOrNull(voiceChoice.selectedItemPosition)?.let {tts.voice=it};tts.setSpeechRate(.75f+rate.progress/100f) }
 private fun startSpeech(){
  if(voices.isEmpty()){status.text="Bitte lokale deutsche Stimme installieren";return}
  tts.stop(); voiceAndSpeed()
  val pieces=segments(cleanRoles(input.text.toString()))
  for((idx,p) in pieces.withIndex()) tts.speak(p,if(idx==0)TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,Bundle(),"play-$idx")
  status.text="Lese ${pieces.size} Abschnitte vor …"
 }
 @Deprecated("Android document picker callback")
 override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
  super.onActivityResult(requestCode,resultCode,data)
  if(resultCode!=RESULT_OK)return
  val uri=data?.data?:return
  if(requestCode==chooseTxt){
   try{contentResolver.openInputStream(uri)!!.bufferedReader().use{input.setText(it.readText())};documentUri=uri;status.text="Text geladen"}
   catch(e:Exception){status.text="Textdatei nicht lesbar: ${e.message}"}
  } else if(requestCode==101){pendingWav=uri;beginExport()}
 }
 private fun beginExport(){
  if(voices.isEmpty()){status.text="Keine lokale deutsche Stimme";return}
  tts.stop();voiceAndSpeed();exportChunks=segments(cleanRoles(input.text.toString()))
  if(exportChunks.isEmpty()){status.text="Kein Text";return}
  exportParts.clear();exportIndex=0;isExporting=true;exportNext()
 }
 private fun exportNext(){
  if(!isExporting)return
  if(exportIndex>=exportChunks.size){isExporting=false;thread { mergeWavs() };return}
  val f=File(cacheDir,"tts_part_${exportIndex}.wav");exportParts.add(f)
  val result=tts.synthesizeToFile(exportChunks[exportIndex],Bundle(),f,"export-${exportIndex}-${UUID.randomUUID()}")
  status.text="Erzeuge Teil ${exportIndex+1} von ${exportChunks.size}"
  if(result!=TextToSpeech.SUCCESS){isExporting=false;status.text="Export konnte nicht gestartet werden"}
 }
 private fun mergeWavs() {
  try {
   // Android TTS providers commonly write RIFF/WAVE PCM. Reject anything incompatible instead of writing a corrupted file.
   val files=exportParts.toList(); var fmt:ByteArray?=null;val pcm=ArrayList<ByteArray>()
   for(f in files){val bytes=f.readBytes(); val parsed=parseWav(bytes);if(fmt==null)fmt=parsed.first else if(!fmt!!.contentEquals(parsed.first))error("Die Audioformate der TTS-Abschnitte unterscheiden sich") ;pcm.add(parsed.second)}
   val total=pcm.sumOf{it.size};val header=makeWavHeader(fmt!!,total)
   val dst=pendingWav?:error("Kein Speicherort gewählt")
   contentResolver.openOutputStream(dst,"wt")!!.use{it.write(header);pcm.forEach { chunk->it.write(chunk) }}
   runOnUiThread{status.text="WAV gespeichert (${total/1024} KiB Audio)."}
  }catch(e:Exception){runOnUiThread{status.text="WAV-Export nicht möglich: ${e.message}"}}
  finally {exportParts.forEach{it.delete()}}
 }
 private fun parseWav(b:ByteArray):Pair<ByteArray,ByteArray> {
  require(b.size>=44 && String(b,0,4)=="RIFF" && String(b,8,4)=="WAVE") {"TTS-Engine erzeugte kein WAV"}
  fun u32(i:Int)= (b[i].toInt() and 255) or ((b[i+1].toInt() and 255) shl 8) or ((b[i+2].toInt() and 255) shl 16) or ((b[i+3].toInt() and 255) shl 24)
  var off=12;var format:ByteArray?=null;var data:ByteArray?=null
  while(off+8<=b.size){val sz=u32(off+4);require(sz>=0 && off+8L+sz<=b.size) {"WAV-Block beschädigt"};val tag=String(b,off,4)
   if(tag=="fmt ") format=b.copyOfRange(off+8,off+8+sz)
   if(tag=="data")data=b.copyOfRange(off+8,off+8+sz)
   off+=8+sz+(sz%2)
  }
  val f=format?:error("Kein WAV-Formatblock");require(f.size>=16 && f[0].toInt()==1 && f[1].toInt()==0) {"Nur unkomprimiertes PCM-WAV unterstützt"}
  return f to (data?:error("Kein WAV-Audioblock"))
 }
 private fun makeWavHeader(fmt:ByteArray, dataSize:Int):ByteArray {
  val fmtPad=fmt.size%2;val dataPad=dataSize%2;val total=4+8+fmt.size+fmtPad+8+dataSize+dataPad
  val b=java.io.ByteArrayOutputStream()
  fun tag(s:String){b.write(s.toByteArray(Charsets.US_ASCII))}
  fun number(n:Int){for(i in 0..3)b.write((n ushr (8*i)) and 255)}
  tag("RIFF");number(total);tag("WAVE");tag("fmt ");number(fmt.size);b.write(fmt);if(fmtPad!=0)b.write(0)
  tag("data");number(dataSize)
  // Pad separately when writing final file, not in the header, as the data count excludes padding.
  return b.toByteArray()
 }
 override fun onDestroy(){ if(::tts.isInitialized){tts.stop();tts.shutdown()};super.onDestroy() }
}
