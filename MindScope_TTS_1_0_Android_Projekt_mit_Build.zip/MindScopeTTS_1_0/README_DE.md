# MindScope TTS 1.0 – Android-Prototyp

**Status:** Quellcode für eine erste Android-App; **nicht kompiliert und nicht auf vivo X300 getestet**. Keine APK enthalten. Dieses Paket ist keine fertig validierte produktive Hörbuch-App.

## Funktionen des aktuellen Prototyps
- TXT-Dateien aus dem Android-Dateimanager öffnen
- Deutsche Stimmen aus der **installierten Android-System-TTS-Engine** anzeigen, sofern diese als offline verfügbar gemeldet werden
- Vorlesen in mehreren sinnvoll geschnittenen Abschnitten, regelbare Sprechgeschwindigkeit
- Kapitelweise Erzeugung von **WAV** mit Fortschrittsanzeige, sofern TTS-Engine RIFF/PCM liefert
- Kein Cloud-Endpunkt oder Internetrecht in der App

## Noch offen
- **Echte separate Charakterstimmen:** Die Rollenkennungen im Text werden in dieser Version erkannt/entfernt; Audio wird vorerst mit der ausgewählten Erzählerstimme gesprochen. Rollenautomatik kommt erst nach dem erfolgreichen Audio-Test.
- **MP3 direkt auf dem Telefon:** noch nicht implementiert. Eine WAV kann bis dahin auf dem PC mit FFmpeg umgewandelt werden (Beispiel unten). Falls die Android-Engine andere als PCM-WAV-Dateien erzeugt, meldet die App einen Exportfehler.
- Aussprachewörterbuch, Wiedergabe ab Position, Qualitätsvergleich mit ASR, Hintergrundjob und langfristige Hörbuchverwaltung.
- Neuere Offline-Engines wie PocketTTS, Kokoly oder Supertonic müssen **separat installiert und eingerichtet** werden; die App liefert die Modellgewichte nicht mit.

## Installation / APK erstellen
1. An Windows-, macOS- oder Linux-Computer **Android Studio** installieren: https://developer.android.com/studio
2. Dieses ZIP entpacken und den Ordner `MindScopeTTS_1_0` mit **Open** öffnen.
3. Android Studio die fehlenden Gradle- und Android-SDK-Komponenten laden lassen. Gradle Plugin 8.7.3 / Kotlin 2.0.21, compileSdk 35, Java 17.
4. Menü **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK erscheint üblicherweise unter `app/build/outputs/apk/debug/app-debug.apk`.
6. APK per USB/Dateitransfer auf vivo X300 übertragen und öffnen; Android kann für den verwendeten Dateimanager einmalig **Installation unbekannter Apps erlauben** verlangen.
7. Auf dem Handy unter **Einstellungen > Text-in-Sprache / TTS-Ausgabe** eine deutsche Offline-Stimme bereitstellen (Android-Menübezeichnungen können abweichen). Starten bzw. neu starten, wenn eine Engine nachinstalliert wurde.
8. App öffnen; TXT laden, Stimme auswählen, Vorlesen testen, anschließend WAV-Ausgabe versuchen.

**Ohne Computer:** Dieses Projekt enthält noch keine installierbare APK. Eine APK direkt auf dem Handy zu kompilieren ist mit Termux und Android-Toolchain grundsätzlich möglich, aber kein verlässlich geprüfter Installationsweg für diesen Stand.

## Probetext
```
ERZÄHLER: Die Memoria Invicta glitt lautlos durch die Dunkelheit.
THANE: Bewahrt die Namen.
KORD: Die Maschine erinnert sich.
```

## MP3-Konvertierung auf PC (Übergangslösung)
`ffmpeg -i MindScope_Hoerbuch.wav -codec:a libmp3lame -qscale:a 3 MindScope_Hoerbuch.mp3`

## Technische Grenzen
- Android `TextToSpeech` schreibt Audio asynchron, Fehler müssen per `UtteranceProgressListener` abgefangen werden; Referenz: https://developer.android.com/reference/android/speech/tts/TextToSpeech
- Endqualität hängt von installierter Engine und deren deutscher Offline-Stimme ab.
- Dieses Projekt braucht vor einer öffentlichen Veröffentlichung einen tatsächlichen Build, Geräte-/Stresstest und Tests von TTS-Stimmen, WAV-Export und Berechtigungen.
- Keine Garantie für exakte Aussprache fremdsprachiger Eigennamen.
